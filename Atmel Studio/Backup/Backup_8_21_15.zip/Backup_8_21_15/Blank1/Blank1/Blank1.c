/*
 * Blank1.c
 *
 * Created: 5/3/2015 3:08:44 PM
 *  Author: andyjambu
 */ 


#include <avr/io.h>

int main(void)
{
    while(1)
	{
    }
}