// SD CARD .....................................................................................................................................

void CSup(unsigned char MODE){// chip select line UP

	PORTB=(1<<PORTB4);

}

void CSdown(unsigned char MODE){// chip select line DOWN

	PORTB=(0<<PORTB4);

}

void Init_SPISystem(void)
{
/* Set MOSI and SCK and CS output, all others input */
DDRB |= (1<<PORTB5)|(1<<PORTB7)|(1<<PORTB4);
/* Enable SPI, Master */
SPCR = (1<<SPE)|(1<<MSTR);

// set clock rate fck/64
SPCR = SPCR|(0<<SPR0)|(1<<SPR1);
SPSR = SPSR|(0<<SPI2X);

//initSD(); //-< ENABLE WHEN SD IS READY!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
delay(2000);

// crank up clock rate fck/4
SPCR &= 0b11111100;
SPSR &= 0b11111110;
//SPCR |= (0<<SPR0)|(0<<SPR1);
//SPSR |= (0<<SPI2X);

}

void SPITransmit(unsigned char data){
	SPDR=data;
	while(!(SPSR & (1<<SPIF))){
		//do nothing
	}

}

unsigned char SPIRecieve(){
	unsigned char data;
	SPDR=0xff;
	
	while(!(SPSR&(1<<SPIF))){
		//do nothing
	}
	data=SPDR;
	return data;
}
	
unsigned char sendCommand(unsigned char command, unsigned long argument){

			unsigned char response;

			SPITransmit((command|0x40));
			SPITransmit(argument>>24);
			SPITransmit(argument>>16);
			SPITransmit(argument>>8);
			SPITransmit(argument);
			SPITransmit(0x95);//CHECKSUM
			
			for(int i=0;i<1000;i++){
				response=SPIRecieve();
				if(response != 0xff){
					break;
				}
			}
			
			for(int j=0;j<1000;j++){
				if(SPIRecieve() == 0xff){
					break;
				}
			}
			
			return response;

	}

void initSD(){
	
	
	unsigned char response;
	CSup;
	
	//DELAY 74 CYCLES
	for(int i=0;i<12;i++){
		SPITransmit(0xff);
	}
	
	CSdown;
	delay(5000);
	
	response=sendCommand(0,0);// CMD0
	
	while(response==0x00){
		fireR();
		response=sendCommand(0,0);// CMD0
	}
	// Check R1 response
	
	/*
	for(int i=0;i<1000;i++){
		if(response != 0x01){
			LEDTestG();		// if !=0x01, turn on blue LED
		}
	}
	*/
	
	/*  IF SDHC (V2.0), then need to fully implement this part of initialization flow
	
	response = sendCommand(0x08,0); //CMD8
	
	// Check R7 response--this is R1 + trailing 32 bit data
	for(int i=0;i<10000;i++){
		if(response != 0x01){
			LEDTestR();		// if !=0x01, turn on red LED
		}
		else
		{
			
		}
	}
	*/
	
	unsigned char tf=0;
	for(int i=0;i<1000;i++){
		response = sendCommand(0x41,0); //ACMD41
		if(response==0x00){
			tf=1;
			break;
		}
	}
	
			if(tf=0){//didnt get the proper response
			ERROR();
		}

	CSup;

	
}

void writeSD(unsigned char * DATA, unsigned long address){

		unsigned char response;
			CSdown;

		for(int i=0;i<10000;i++){
			response=sendCommand(0x18,address);// CMD24
			if(response==0x00){
				break;
		}
		}		
		
	// 1 byte Data Token
	unsigned char datatoken=0xfe;
	SPITransmit(datatoken);
	
	//datablock is an array , send through 8 bit 4 loop
	for(int i=0;i<512;i++){//512 is the default block size for SDv1
	SPITransmit(DATA[i]);
	
	
	// 2 byte CRC
	SPITransmit(0x95);
	SPITransmit(0x95);
	
	for(int i=0; i<10000; i++){
		response = SPIRecieve(); //look @ SPDR
		
		if(response == 0x05 ){//If data accepted
			break;
	} else if(response == 0x0b){ // If CRC error
		LEDTestY(); // yellow LED error signal	
	} else if(response == 0x0d){ // If CRC error
		LEDTestG(); // green LED error signal		
	}		
		
	
		for(unsigned long j=0; j<50000; j++)
	{
		if(SPIRecieve()==0xff){
			 break;
	}
	}	
				CSup;
				return response;
				

}

void readSD(unsigned char * DATA, unsigned long address){
		unsigned char response;
		CSdown;
		for(int i=0;i<10000;i++){
			response=sendCommand(0x11,address);// CMD17
			if(response==0x00){break;}
		}		
		/*
		for(int j=0;j<3;j++){ // to get rid of 0xff's in front
					SPIRecieve();
		}
*/		
		while(!(SPIRecieve()==0xfe)){//do nothing
		}


		for(int i=0;i<512;i++){//512 is the default block size for SDv1
			DATA[i]=SPIRecieve();	
		}
	
		SPIRecieve();
		SPIRecieve();
		for(unsigned long j=0; j<50000; j++){
			if(SPIRecieve()==0xff) {
				break;
			}
		}	
		CSup;


}







