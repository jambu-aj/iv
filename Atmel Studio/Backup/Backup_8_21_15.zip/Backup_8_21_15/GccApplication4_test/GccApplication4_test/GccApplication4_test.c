/*
 * GccApplication4_test.c
 *
 * Created: 2/13/2015 5:16:16 PM
 *  Author: andyjambu
 */ 


#include <avr/io.h>


int main(void)
{
    while(1)
    {
		//Init_SPISystem();
		
/* Set MOSI and SCK and CS output, all others input */
DDRB |= (1<<PORTB5)|(1<<PORTB7)|(1<<PORTB4);
/* Enable SPI, Master */
SPCR = (1<<SPE)|(1<<MSTR);

// set clock rate fck/64
SPCR = SPCR|(0<<SPR0)|(1<<SPR1);
SPSR = SPSR|(0<<SPI2X);

//initSD(); //-< ENABLE WHEN SD IS READY!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
delay(2000);

// crank up clock rate fck/4
SPCR &= 0b11111100;
SPSR &= 0b11111110;
//SPCR |= (0<<SPR0)|(0<<SPR1);
//SPSR |= (0<<SPI2X);

		
		
		//CSdown();
		//SPITransmit(0b001010010110000000000101);
        //TODO:: Please write your application code 
		//0b110000000000101 - bits 0->15, turning on Weight
		// So now I need the 8 bit address, out of which the lower five bits are the address and the 21st is the r/w bit
    }
}